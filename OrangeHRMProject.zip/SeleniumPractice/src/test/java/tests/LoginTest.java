package tests;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pages.AddEmployee;
import pages.DashboardPage;
import pages.LoginPage;
import pages.ReadingData;

public class LoginTest extends ReadingData {
	WebDriver driver;
	
	@BeforeMethod
	public void login() throws Exception {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");

		LoginPage loginPage = new LoginPage(driver);
		loginPage.login("Admin", "admin123");
	}

		@Test
		public void navigate() throws Exception {
		DashboardPage dashboard = new DashboardPage(driver);
		dashboard.navigateToPIM();
		
		AddEmployee addEmp = new AddEmployee(driver);
		addEmp.ClickOnAddEmployeeBtn();
		addEmp.FirstName(ReadingData.getValueExcel(0, 1));
		addEmp.LastName(ReadingData.getValueExcel(1, 1));
		addEmp.EmployeeID();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		addEmp.addAgain();
		
		
		AddEmployee addEmp1 = new AddEmployee(driver);
		addEmp1.ClickOnAddEmployeeBtn();
		addEmp1.FirstName(ReadingData.getValueExcel(0, 2));
		addEmp1.LastName(ReadingData.getValueExcel(1, 2));
		addEmp1.EmployeeID();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		addEmp1.addAgain();
		
		AddEmployee addEmp2 = new AddEmployee(driver);
		addEmp2.ClickOnAddEmployeeBtn();
		addEmp2.FirstName(ReadingData.getValueExcel(0, 3));
		addEmp2.LastName(ReadingData.getValueExcel(1, 3));
		addEmp2.EmployeeID();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		addEmp2.EmpList();
		addEmp2.VerifyNames(ReadingData.getValueExcel(0, 1));
		
		LoginPage login = new LoginPage(driver);
		login.logout();
		
		driver.quit();
	}
}
