package pages;

import java.io.FileInputStream;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;

public class ReadingData {

	public static String getValueExcel(int x,int y) throws Exception {
		
		//Importing the workbook from device
		FileInputStream f = new FileInputStream("src\\test\\java\\pages\\Book1.xls");
		
		//Opening the workbook 
		Workbook wb = Workbook.getWorkbook(f);
		
		//Selecting the sheet in it
		Sheet s = wb.getSheet("Sheet2");
		
		//Instead of hardcoding the number of rows we can have below msg
		Cell value = s.getCell(x, y);
		String Value = s.toString();
		
		return value.getContents();
	}

}
