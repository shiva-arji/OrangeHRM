package pages;

import java.time.Duration;
import java.util.Random;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AddEmployee extends ReadingData{
	
	WebDriver driver;

	//Add employees
	@FindBy(xpath = "//*[text()='Add Employee']") public WebElement AddEmployee;  	
	@FindBy(xpath = "(//*[text()='Add Employee'])[2]") public WebElement Text;
	@FindBy(name = "firstName") public WebElement FirstName;
	@FindBy(xpath ="//*[@placeholder='Middle name']") public WebElement MiddleName;
	@FindBy(xpath="//*[@placeholder='Last Name']") public WebElement LastName;
	@FindBy(xpath="//*[text()='Create Login Details']/preceding::input[1]") public WebElement EmpId;
	@FindBy(xpath="//button[text()=' Save ']") public WebElement Save;
	@FindBy(xpath="//a[text()='Add Employee']") public WebElement AddAgain;
	
	//Verify employees
	@FindBy(xpath = "//a[text()='Employee List']") public WebElement EmployeeList;
	@FindBy(xpath = "//label[text()='Employee Name']/following::input[1]") public WebElement VerifyText;
	@FindBy(xpath = "//button[text()=' Search ']") public WebElement Search; 
	@FindBy(xpath = "(//div[@role='cell']//div[not(normalize-space())])[1]/following::div[3]") public WebElement VerifyName;
	
	
	Random rand = new Random();
    int randomNumber = rand.nextInt(900000) + 100000;
	
	public AddEmployee(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void ClickOnAddEmployee() {
		AddEmployee.click();
	}
	
	public void ClickOnAddEmployeeBtn() throws InterruptedException {
		AddEmployee.click();
		Thread.sleep(5000);
	}
	public void Wait() {
		
		if(!Text.isDisplayed()) {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
			wait.until(ExpectedConditions.visibilityOf(FirstName));
		}
	}
	
	public void FirstName(String fname) {
		FirstName.sendKeys(fname);
	}
		
	public void MiddleName(String mname) {
		MiddleName.sendKeys(mname);
	}
	public void LastName(String lname) {
		LastName.sendKeys(lname);
		
	}
	public void EmployeeID() {
		EmpId.clear();
		EmpId.sendKeys(String.valueOf(randomNumber));
		Save.click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.elementToBeClickable(AddAgain));
	}
		
	public void addAgain() {
		AddAgain.click();
	}
		
	public void EmpList() {
		EmployeeList.click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOf(VerifyText));
	}
	
	public void VerifyNames(String fname) {
		VerifyText.sendKeys(fname);
		Search.click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,1000)");
		
		String name = VerifyName.getText();
		if(name == fname) {
			System.out.println("Name Verified");
		}
		else {
			System.out.println("Fail");
		}
		
	}

}

