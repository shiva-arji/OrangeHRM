package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	WebDriver driver;

	
	//Login
	@FindBy(name = "username") public WebElement username;

	@FindBy(name = "password") public WebElement password;

	@FindBy(xpath = "//*[@type='submit']") public WebElement loginButton;
	
	//Logout
	@FindBy(xpath = "//li[@class='oxd-userdropdown']") public WebElement Dropdown;
	@FindBy(xpath = "//a[text()='Logout']") public WebElement Logout;
	
//constructor to initialize the browser
	
	public LoginPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public void login(String user, String pass) {
		username.sendKeys(user);
		password.sendKeys(pass);
		loginButton.click();
	}
	
	public void logout() {
		Dropdown.click();
		Logout.click();
	}
}